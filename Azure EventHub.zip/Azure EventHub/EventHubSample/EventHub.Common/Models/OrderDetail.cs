﻿using System;
using System.Collections.Generic;
using System.Runtime.Serialization;
using System.Text;

namespace EventHub.Common.Models
{
    [DataContract]
    public class OrderDetail
    {
        public OrderDetail()
        {
            this.Items = new List<OrderItem>();
        }

        [DataMember]
        public string Id { get; set; }

        [DataMember]
        public DateTime OrderDate { get; set; }

        [DataMember]
        public string DeliveryAddress { get; set; }

        [DataMember]
        public string BillingAddress { get; set; }

        [DataMember]
        public List<OrderItem> Items { get; set; }

        [DataMember]
        public string State { get; set; }

    }
}
