﻿using EventHub.Common.Models;
using EventHub.Consumer.Processors;
using Microsoft.Azure.EventHubs;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace EventHub.Consumer
{
    public class Program
    {
        private const string eventHubConnectionString = "Endpoint=sb://sonu-eventhub.servicebus.windows.net/;SharedAccessKeyName=RootManageSharedAccessKey;SharedAccessKey=krnxWNLenftz++m4cuCsDo+oEf+3Augek0L/xMvoaPw=";
        private const string entityPath = "eshopeventhub";
        private const string storageContainerName = "data";
        private const string storageAccountName = "synevrystorage";
        private const string storageAccountKey = "QcgyFnDKGIPsYOjumuqcBesNttgffMsNxllSDyTSzcDxcYEirCxUggxsdtAeXP3YxxQCxmLt4tB2KmEntL1SsA==";

        private static readonly string storageConnectionString = string.Format("DefaultEndpointsProtocol=https;AccountName={0};AccountKey={1}", storageAccountName, storageAccountKey);

        
        static void Main(string[] args)
        {
            MainAsync().GetAwaiter().GetResult();
        }

        private static async Task MainAsync()
        {
            var connectionStringBuilder = new EventHubsConnectionStringBuilder(eventHubConnectionString)
            {
                EntityPath = entityPath
            };

            EventHubClient client = EventHubClient.CreateFromConnectionString(connectionStringBuilder.ToString());

            var runtimeInfo = await client.GetRuntimeInformationAsync();


            //Only first partitions
            //var receiver = client.CreateReceiver(PartitionReceiver.DefaultConsumerGroupName, "0", EventPosition.FromStart());
            //IPartitionReceiveHandler eventProcessor = new PartitionReceiveHandler("0");
            //receiver.SetReceiveHandler(eventProcessor);

            foreach (var partitionId in runtimeInfo.PartitionIds)
            {
                var receiver = client.CreateReceiver(PartitionReceiver.DefaultConsumerGroupName, partitionId, EventPosition.FromStart());
                IPartitionReceiveHandler eventProcessor = new PartitionReceiveHandler(partitionId);                
                receiver.SetReceiveHandler(eventProcessor);
                                
            }
            

            Console.WriteLine("Press ENTER to stop");
            Console.ReadLine();
        }

        
    }
}
