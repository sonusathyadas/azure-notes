﻿using EventHub.Common.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace EventHub.Publisher.Utils
{
    public static class OrderGenerator
    {
        private static string[] states = new[]
        {
            "Kerala", "Tamil Nadu", "Karnataka", "Andhra Pradesh", "Telangana", "Goa", "Odisha", "West Bengal", "Maharashtra",
            "Gujarat", "Rajastan", "Madhya Pradesh", "Haryana", "Punjab", "Delhi", "Jharghand", "Uttrakhand", "Mizoram",
            "Assam", "Manipur", "Bihar", "Jammu and Kashmir","Himachal Pradesh", "Chhattisgarh", "Sikkim", "Nagaland",
            "Arunachal Pradesh", "Meghalaya", "Missoram"
        };

        private static Buyer[] buyers = new Buyer[] {
           new Buyer{BuyerId= "B001", BillingAddress="Mangalya , A302, Andheri", DeliveryAddress="Mangalya , A302, Andheri" },
           new Buyer{BuyerId="B002", BillingAddress="D20, Tarawade, Vikhroli", DeliveryAddress="D20, Tarawade, Vikhroli"},
           new Buyer{BuyerId="B003", BillingAddress="Flat 4, Floor 4, Anindya building, Kurla", DeliveryAddress="Flat 4, Floor 4, Anindya building, Kurla"},
           new Buyer{BuyerId="B004",BillingAddress="A101, Kushal Hosuing Society", DeliveryAddress="A101, Kushal Hosuing Society" },
           new Buyer{BuyerId="B005", BillingAddress="A302, Mahajan CHS, Kurla West", DeliveryAddress="A302, Mahajan CHS, Kurla West"},
           new Buyer{BuyerId="B006",BillingAddress="D320, Bhushan Bhavan, Gkhatkoper", DeliveryAddress="D320, Bhushan Bhavan, Gkhatkoper" },
           new Buyer{BuyerId="B007",BillingAddress="A11, Milind Parve, Banglore", DeliveryAddress="A11, Milind Parve, Banglore" },
           new Buyer{BuyerId="B008", BillingAddress="S20, Aurion Pro, Rabale, Airoli", DeliveryAddress="S20, Aurion Pro, Rabale, Airoli"},
           new Buyer{BuyerId="B009", BillingAddress="Datamatics, Akruti Builing, MIDC, Andheri E", DeliveryAddress="Datamatics, Akruti Builing, MIDC, Andheri E"},
           new Buyer{BuyerId="B010", BillingAddress="Capgemini, Godrej Campus, Vikhroli", DeliveryAddress="Capgemini, Godrej Campus, Vikhroli"}
        };

        private static OrderItem[] items = new[]
        {
            new OrderItem{ ProductId ="P1", ProductName="HP Envy 13", UnitPrice=72000, Units=1, PictureUrl="http://localhost:8080/eshop/images/hp-envy-13.jpg" },
            new OrderItem{ ProductId ="P2", ProductName="HP Pavilion G6", UnitPrice=54000, Units=1, PictureUrl="http://localhost:8080/eshop/images/hp-pavilion-g6.jpg" },
            new OrderItem{ ProductId ="P3", ProductName="Xiomi MI6", UnitPrice=24300, Units=1, PictureUrl="http://localhost:8080/eshop/images/mi6.jpg" },
            new OrderItem{ ProductId ="P4", ProductName="Honor 9 Lite", UnitPrice=11999, Units=1, PictureUrl="http://localhost:8080/eshop/images/honor9-lite.jpg" },
            new OrderItem{ ProductId ="P5", ProductName="Honor 9 Pro", UnitPrice=24999, Units=1, PictureUrl="http://localhost:8080/eshop/images/honor9-pro.jpg" },
            new OrderItem{ ProductId ="P6", ProductName="Western Digital 1TB HDD X100", UnitPrice=6500, Units=1, PictureUrl="http://localhost:8080/eshop/images/wdx100.jpg" },
            new OrderItem{ ProductId ="P7", ProductName="Logitech Mouse A11", UnitPrice=850, Units=1, PictureUrl="http://localhost:8080/eshop/images/ltech-a11.jpg" },
            new OrderItem{ ProductId ="P8", ProductName="Philips LED L4356", UnitPrice=17600, Units=1, PictureUrl="http://localhost:8080/eshop/images/philips-L4356.jpg" },
            new OrderItem{ ProductId ="P9", ProductName="Wildcraft Backpack", UnitPrice=1499, Units=1, PictureUrl="http://localhost:8080/eshop/images/wildcraft.jpg" },
            new OrderItem{ ProductId ="P10", ProductName="DELL Inspiron 15R", UnitPrice=56400, Units=1, PictureUrl="http://localhost:8080/eshop/images/dell-i15r.jpg" },
            new OrderItem{ ProductId ="P11", ProductName="Sonic Mens watch", UnitPrice=1800, Units=1, PictureUrl="http://localhost:8080/eshop/images/sonic-4xx.jpg" },
            new OrderItem{ ProductId ="P12", ProductName="Bisleri 1L", UnitPrice=20, Units=5, PictureUrl="http://localhost:8080/eshop/images/bisleri1l.jpg" },
            new OrderItem{ ProductId ="P13", ProductName="Bisleri 1L", UnitPrice=20, Units=2, PictureUrl="http://localhost:8080/eshop/images/bisleri1l.jpg" },
            new OrderItem{ ProductId ="P14", ProductName="Laptop Case 13inch", UnitPrice=3200, Units=1, PictureUrl="http://localhost:8080/eshop/images/lpcase-210.jpg" },
            new OrderItem{ ProductId ="P15", ProductName="Tablemate", UnitPrice=4500, Units=1, PictureUrl="http://localhost:8080/eshop/images/tablemate.jpg" }
        };

        private static Random buyerRnd = new Random();
        private static Random itemRnd = new Random();
        private static Random itemCountRnd = new Random();
        private static Random stateRnd = new Random();

        public static int GetStateIndex(string state)
        {
            var index = 0;
            for (var i = 0; i < states.Length; i++)
            {
                if (states[i] == state)
                {
                    index = i;
                    break;
                }
            }
            return index;
        }

        public static OrderDetail CreateOrder()
        {
            
            var buyer = buyers[buyerRnd.Next(0, buyers.Length-1)];
            var itemCount = itemCountRnd.Next(1, items.Length);
            List<OrderItem> orderItems = new List<OrderItem>();
            for (var i=1;i<=itemCount;i++)
            {
                orderItems.Add(items[itemRnd.Next(0, items.Length - 1)]);
            }
            return new OrderDetail()
            {
                BillingAddress=buyer.BillingAddress,
                DeliveryAddress=buyer.DeliveryAddress,
                Items=orderItems,
                OrderDate=DateTime.Now,
                Id=Guid.NewGuid().ToString(),
                State=states[stateRnd.Next(0, states.Length-1)]
            };
        }

    }

    internal class Buyer
    {
        public string BuyerId { get; set; }
        public string DeliveryAddress { get; set; }
        public string BillingAddress { get; set; }
    }
}
