import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { AdminComponent } from './admin.component';
import { ReportComponent } from './components/report/report.component';
import { UserListComponent } from './components/user-list/user-list.component';

const routes: Routes = [
    { path: '', component: AdminComponent }, //http://localhost:4200/admin/
    { path:'report', component:ReportComponent}, //http://localhost:4200/admin/report
    { path:'users', component:UserListComponent} //http://localhost:4200/admin/users
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AdminRoutingModule { }
