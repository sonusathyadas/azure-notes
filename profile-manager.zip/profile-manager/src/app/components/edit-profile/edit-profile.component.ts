import { Component, OnInit, ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { IProfile } from 'src/app/models/IProfile';
import { ProfileService } from 'src/app/services/profile.service';

@Component({
    selector: 'edit-profile',
    templateUrl: './edit-profile.component.html',
    styleUrls: ['./edit-profile.component.css']
})
export class EditProfileComponent implements OnInit {

    profile: IProfile;
    @ViewChild('frm')form:NgForm;

    constructor(private route: ActivatedRoute, private router: Router, private svc: ProfileService) {
        this.profile = this.route.snapshot.data["profile"];
    }

    ngOnInit(): void {
    }

    public get Dirty():boolean{
        return this.form.dirty;
    }
    
    update(frm) {
        if (frm.valid) {
            this.svc.updateProfile(this.profile)
                .subscribe(
                    (res) => { this.router.navigate(['/']) },
                    (err) => { console.log("Error:", err) }
                )
        } else {
            alert("Invalid data")
        }
    }

}
