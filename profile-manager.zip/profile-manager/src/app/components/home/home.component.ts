import { Component, OnDestroy, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import { IProfile } from 'src/app/models/IProfile';
import { ProfileService } from '../../services/profile.service';

@Component({
    selector: 'home',
    templateUrl: './home.component.html',
    styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit, OnDestroy {

    //profiles: IProfile[]; //default value is undefined
    profiles:Observable<IProfile[]>;

    constructor(private svc: ProfileService) {
        //this.profiles = this.svc.getProfiles(); //initializing the profiles array
    }

    ngOnInit(): void {
        // this.svc.getProfiles()
        //     .subscribe(
        //         (data) => this.profiles = data,
        //         (err) => console.log("Error", err)
        //     )
        this.profiles = this.svc.getProfiles();
    }

    ngOnDestroy(): void {
        console.log("Unloading Home component")
    }
}
