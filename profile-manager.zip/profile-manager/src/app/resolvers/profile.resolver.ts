import { Injectable } from "@angular/core";
import { ActivatedRouteSnapshot, Resolve, RouterStateSnapshot } from '@angular/router';
import { Observable } from 'rxjs';
import { IProfile } from '../models/IProfile';
import { ProfileService } from '../services/profile.service';

@Injectable({
    providedIn:'root'
})
export class ProfileResolver implements Resolve<IProfile>{

    constructor(private svc:ProfileService){

    }

    resolve(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<IProfile> {
        let id = route.params["id"];
        return this.svc.getProfileById(id);
    }

}