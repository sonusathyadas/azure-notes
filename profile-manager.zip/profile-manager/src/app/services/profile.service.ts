import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';
import { PROFILES } from '../data/inmemory-data';
import { IProfile } from '../models/IProfile';

@Injectable({
    providedIn: 'root'
})
export class ProfileService {

    //profiles: any[] = PROFILES;
    readonly apiBaseUrl:string = "http://localhost:3000/profiles";

    constructor(private http:HttpClient) { }

    getProfiles():Observable<IProfile[]>{
        return this.http.get<IProfile[]>(this.apiBaseUrl)
    }

    getProfileById(id:number):Observable<IProfile>{
        let url = `${this.apiBaseUrl}/${id}`;
        return this.http.get<IProfile>(url);
    }

    addProfile(profile:IProfile):Observable<IProfile>{
        return this.http.post<IProfile>(this.apiBaseUrl,profile);
    }

    updateProfile(profile:IProfile):Observable<IProfile>{
        let url = `${this.apiBaseUrl}/${profile.id}`;
        return this.http.put<IProfile>(url,profile);
    }
}
